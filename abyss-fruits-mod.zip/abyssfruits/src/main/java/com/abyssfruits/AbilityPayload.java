package com.abyssfruits;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: "the player pressed ability key #index". */
public record AbilityPayload(int index) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<AbilityPayload> TYPE =
            new CustomPacketPayload.Type<>(AbyssFruits.id("ability"));

    public static final StreamCodec<RegistryFriendlyByteBuf, AbilityPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.VAR_INT, AbilityPayload::index, AbilityPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
