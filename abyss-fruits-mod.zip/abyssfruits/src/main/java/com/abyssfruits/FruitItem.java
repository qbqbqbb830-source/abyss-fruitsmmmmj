package com.abyssfruits;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class FruitItem extends Item {
    public final FruitType type;

    public FruitItem(Item.Properties props, FruitType type) {
        super(props);
        this.type = type;
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        ItemStack result = super.finishUsingItem(stack, level, entity);
        if (level instanceof ServerLevel sl && entity instanceof ServerPlayer player) {
            Abilities.awaken(sl, player, type);
        }
        return result;
    }
}
