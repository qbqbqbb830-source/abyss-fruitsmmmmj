package com.abyssfruits;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.TargetGoal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.UUID;

/**
 * Shadow Wraith.
 *  - With an owner  : friendly minion (follows owner, fights owner's enemies, vanishes after a while).
 *  - Without owner  : hostile hunter that only targets players who own a fruit power.
 * Special AI: "blink" behind the target when it is far away.
 */
public class ShadowWraith extends PathfinderMob {
    private UUID ownerId;
    private int life = -1;
    private int blinkCd = 40;
    private Vec3 blinkDest;

    public ShadowWraith(EntityType<? extends ShadowWraith> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30)
                .add(Attributes.MOVEMENT_SPEED, 0.32)
                .add(Attributes.ATTACK_DAMAGE, 6)
                .add(Attributes.FOLLOW_RANGE, 32)
                .add(Attributes.ARMOR, 2);
    }

    public void setOwner(UUID owner, int lifeTicks) {
        this.ownerId = owner;
        this.life = lifeTicks;
    }

    public UUID getOwnerId() {
        return ownerId;
    }

    // ------------------------------------------------------------------- goals
    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new BlinkGoal());
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.25, true));
        goalSelector.addGoal(3, new FollowOwnerGoal());
        goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8f));
        goalSelector.addGoal(6, new RandomLookAroundGoal(this));

        targetSelector.addGoal(1, new OwnerTargetGoal());
        targetSelector.addGoal(2, new HurtByTargetGoal(this));
        targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false,
                (LivingEntity e, ServerLevel l) -> ownerId == null
                        && e instanceof Player p
                        && PowerData.get(p) != null
                        && !p.isCreative() && !p.isSpectator()));
    }

    /** Hostile AI trick: teleport behind a far-away target. */
    private class BlinkGoal extends Goal {
        BlinkGoal() { setFlags(EnumSet.of(Flag.MOVE)); }

        @Override
        public boolean canUse() {
            LivingEntity t = getTarget();
            if (t == null || blinkCd > 0) return false;
            double d = distanceToSqr(t);
            if (d < 64 || d > 1600) return false;
            Vec3 back = t.position().subtract(t.getLookAngle().multiply(1, 0, 1).normalize().scale(2.5));
            Vec3 delta = new Vec3(back.x - getX(), t.getY() - getY(), back.z - getZ());
            if (!level().noCollision(ShadowWraith.this, getBoundingBox().move(delta))) return false;
            blinkDest = new Vec3(back.x, t.getY(), back.z);
            return true;
        }

        @Override
        public void start() {
            if (level() instanceof ServerLevel sl) {
                Fx.burst(sl, AbyssFruits.SHADOW_WISP, position().add(0, 1, 0), 25, 0.4, 0.08);
                Fx.burst(sl, net.minecraft.core.particles.ParticleTypes.LARGE_SMOKE, position().add(0, 1, 0), 12, 0.3, 0.03);
            }
            setPos(blinkDest.x, blinkDest.y, blinkDest.z);
            getNavigation().stop();
            playSound(SoundEvents.ENDERMAN_TELEPORT, 1f, 0.6f);
            if (level() instanceof ServerLevel sl) {
                Fx.burst(sl, AbyssFruits.SHADOW_WISP, position().add(0, 1, 0), 25, 0.4, 0.08);
            }
            blinkCd = 100;
        }

        @Override
        public boolean canContinueToUse() { return false; }
    }

    /** Minion keeps close to its owner. */
    private class FollowOwnerGoal extends Goal {
        private Player owner;

        FollowOwnerGoal() { setFlags(EnumSet.of(Flag.MOVE)); }

        @Override
        public boolean canUse() {
            if (ownerId == null || getTarget() != null) return false;
            owner = level().getPlayerByUUID(ownerId);
            return owner != null && distanceToSqr(owner) > 16;
        }

        @Override
        public boolean canContinueToUse() {
            return owner != null && owner.isAlive() && getTarget() == null
                    && distanceToSqr(owner) > 6 && !getNavigation().isDone();
        }

        @Override
        public void tick() {
            getNavigation().moveTo(owner, 1.3);
            if (distanceToSqr(owner) > 400) setPos(owner.getX(), owner.getY(), owner.getZ());
        }

        @Override
        public void stop() { getNavigation().stop(); }
    }

    /** Minion attacks whatever the owner attacks / whatever attacks the owner. */
    private class OwnerTargetGoal extends TargetGoal {
        private LivingEntity pick;

        OwnerTargetGoal() {
            super(ShadowWraith.this, false);
            setFlags(EnumSet.of(Flag.TARGET));
        }

        @Override
        public boolean canUse() {
            if (ownerId == null) return false;
            Player o = level().getPlayerByUUID(ownerId);
            if (o == null) return false;
            LivingEntity c = o.getLastHurtMob();
            if (c != null && c.isAlive() && o.tickCount - o.getLastHurtMobTimestamp() < 100) {
                pick = c;
            } else {
                c = o.getLastHurtByMob();
                if (c != null && c.isAlive() && o.tickCount - o.getLastHurtByMobTimestamp() < 100) pick = c;
                else return false;
            }
            return !(pick instanceof ShadowWraith) && canAttack(pick, TargetingConditions.DEFAULT);
        }

        @Override
        public void start() {
            mob.setTarget(pick);
            super.start();
        }
    }

    // ---------------------------------------------------------------- behaviour
    @Override
    public boolean canAttack(LivingEntity target) {
        if (ownerId != null && (target.getUUID().equals(ownerId)
                || (target instanceof ShadowWraith w && ownerId.equals(w.ownerId)))) return false;
        return super.canAttack(target);
    }

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        if (ownerId != null && source.getEntity() != null && ownerId.equals(source.getEntity().getUUID())) return false;
        return super.hurtServer(level, source, amount);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (blinkCd > 0) blinkCd--;
        if (level() instanceof ServerLevel sl) {
            if (tickCount % 3 == 0) {
                sl.sendParticles(AbyssFruits.SHADOW_WISP, getX(), getY() + 1.0, getZ(), 2, 0.3, 0.6, 0.3, 0.01);
            }
            if (life > 0 && --life == 0) {
                Fx.burst(sl, AbyssFruits.SHADOW_WISP, position().add(0, 1, 0), 40, 0.5, 0.1);
                Fx.burst(sl, net.minecraft.core.particles.ParticleTypes.LARGE_SMOKE, position().add(0, 1, 0), 15, 0.4, 0.04);
                discard();
            }
        }
    }

    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.WARDEN_AMBIENT; }

    @Override
    protected void addAdditionalSaveData(ValueOutput out) {
        super.addAdditionalSaveData(out);
        out.putInt("Life", life);
        if (ownerId != null) out.putString("Owner", ownerId.toString());
    }

    @Override
    protected void readAdditionalSaveData(ValueInput in) {
        super.readAdditionalSaveData(in);
        life = in.getIntOr("Life", -1);
        String s = in.getStringOr("Owner", "");
        if (!s.isEmpty()) {
            try { ownerId = UUID.fromString(s); } catch (IllegalArgumentException ignored) {}
        }
    }
}
