package com.abyssfruits.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.util.Mth;

/** Custom 3D model: tall lanky horned wraith with long arms and a tattered cloak. */
public class WraithModel extends EntityModel<LivingEntityRenderState> {
    private final ModelPart head, rightArm, leftArm, rightLeg, leftLeg;

    public WraithModel(ModelPart root) {
        super(root);
        this.head = root.getChild("head");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        r.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4, -8, -4, 8, 8, 8)
                .texOffs(32, 0).addBox(-4.5f, -14, -1, 1, 6, 1)
                .texOffs(36, 0).addBox(3.5f, -14, -1, 1, 6, 1)
                .texOffs(32, 8).addBox(-5.5f, -16, -1, 1, 3, 1)
                .texOffs(36, 8).addBox(4.5f, -16, -1, 1, 3, 1), PartPose.ZERO);
        r.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(16, 16).addBox(-4, 0, -2, 8, 12, 4)
                .texOffs(24, 32).addBox(-3, 12, 1.5f, 6, 10, 1)
                .texOffs(0, 48).addBox(-6, -1, -2.5f, 12, 2, 5), PartPose.ZERO);
        r.addOrReplaceChild("right_arm", CubeListBuilder.create()
                .texOffs(40, 16).addBox(-3, -2, -1.5f, 3, 17, 3), PartPose.offset(-5, 2, 0));
        r.addOrReplaceChild("left_arm", CubeListBuilder.create()
                .texOffs(40, 36).addBox(0, -2, -1.5f, 3, 17, 3), PartPose.offset(5, 2, 0));
        r.addOrReplaceChild("right_leg", CubeListBuilder.create()
                .texOffs(0, 16).addBox(-2, 0, -2, 4, 12, 4), PartPose.offset(-2, 12, 0));
        r.addOrReplaceChild("left_leg", CubeListBuilder.create()
                .texOffs(0, 32).addBox(-2, 0, -2, 4, 12, 4), PartPose.offset(2, 12, 0));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(LivingEntityRenderState s) {
        super.setupAnim(s);
        float pos = s.walkAnimationPos;
        float spd = s.walkAnimationSpeed;
        head.yRot = s.yRot * Mth.DEG_TO_RAD;
        head.xRot = s.xRot * Mth.DEG_TO_RAD;
        rightLeg.xRot = Mth.cos(pos * 0.6662f) * 1.4f * spd;
        leftLeg.xRot = Mth.cos(pos * 0.6662f + Mth.PI) * 1.4f * spd;
        float sway = Mth.sin(s.ageInTicks * 0.09f) * 0.06f;
        rightArm.xRot = -1.2f + Mth.cos(pos * 0.6662f + Mth.PI) * 0.6f * spd + sway;
        leftArm.xRot = -1.2f + Mth.cos(pos * 0.6662f) * 0.6f * spd - sway;
        rightArm.zRot = 0.1f + sway;
        leftArm.zRot = -0.1f - sway;
    }
}
