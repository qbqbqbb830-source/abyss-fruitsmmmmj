package com.abyssfruits.client;

import com.abyssfruits.AbyssFruits;
import com.abyssfruits.ShadowWraith;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;

public class WraithRenderer extends MobRenderer<ShadowWraith, LivingEntityRenderState, WraithModel> {
    private static final Identifier TEXTURE = AbyssFruits.id("textures/entity/shadow_wraith.png");

    public WraithRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new WraithModel(ctx.bakeLayer(AbyssFruitsClient.WRAITH_LAYER)), 0.5f);
    }

    @Override
    public LivingEntityRenderState createRenderState() {
        return new LivingEntityRenderState();
    }

    @Override
    public Identifier getTextureLocation(LivingEntityRenderState state) {
        return TEXTURE;
    }
}
