package com.abyssfruits;

import java.util.ArrayList;
import java.util.List;

/** Tiny server-thread scheduler used to animate FX over several ticks. */
public final class Scheduler {
    private record Task(int[] left, Runnable run) {}

    private static final List<Task> TASKS = new ArrayList<>();

    private Scheduler() {}

    public static void in(int ticks, Runnable r) {
        if (ticks <= 0) r.run();
        else TASKS.add(new Task(new int[]{ticks}, r));
    }

    public static void tick() {
        if (TASKS.isEmpty()) return;
        List<Task> due = new ArrayList<>();
        TASKS.removeIf(t -> {
            if (--t.left[0] <= 0) { due.add(t); return true; }
            return false;
        });
        for (Task t : due) {
            try { t.run.run(); } catch (Exception ignored) {}
        }
    }

    public static void clear() {
        TASKS.clear();
    }
}
