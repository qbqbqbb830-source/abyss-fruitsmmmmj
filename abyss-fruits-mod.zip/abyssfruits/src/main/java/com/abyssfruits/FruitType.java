package com.abyssfruits;

public enum FruitType {
    SHADOW("shadow", 200, 600),
    BLOOD("blood", 160, 400),
    FLAME("flame", 100, 300),
    GRAVITY("gravity", 120, 260);

    public final String id;
    public final int[] cooldowns;

    FruitType(String id, int cd1, int cd2) {
        this.id = id;
        this.cooldowns = new int[]{cd1, cd2};
    }

    public static FruitType byId(String s) {
        for (FruitType t : values()) if (t.id.equals(s)) return t;
        return null;
    }
}
