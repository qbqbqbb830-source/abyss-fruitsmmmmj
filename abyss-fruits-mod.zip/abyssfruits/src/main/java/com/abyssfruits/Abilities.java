package com.abyssfruits;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public final class Abilities {
    private Abilities() {}

    public static ParticleOptions signature(FruitType t) {
        return switch (t) {
            case SHADOW -> AbyssFruits.SHADOW_WISP;
            case BLOOD -> AbyssFruits.BLOOD_DROP;
            case FLAME -> AbyssFruits.BLACK_EMBER;
            case GRAVITY -> AbyssFruits.GRAVITY_ORB;
        };
    }

    // ------------------------------------------------------------------ awaken
    public static void awaken(ServerLevel level, ServerPlayer player, FruitType type) {
        if (PowerData.get(player) != null) {
            // Devil-fruit rule: a second fruit kills you.
            player.displayClientMessage(Component.translatable("msg.abyssfruits.rejected"), false);
            Fx.burst(level, Fx.darkDust(), player.position().add(0, 1, 0), 60, 0.6, 0.2);
            player.hurtServer(level, level.damageSources().genericKill(), Float.MAX_VALUE);
            return;
        }
        PowerData.set(player, type);
        player.displayClientMessage(Component.translatable("msg.abyssfruits.awakened." + type.id), false);
        Vec3 c = player.position();
        Fx.sound(level, c, SoundEvents.WITHER_SPAWN, 0.8f, 1.4f);
        Fx.sound(level, c, SoundEvents.PLAYER_BURP, 1f, 0.5f);
        ParticleOptions sig = signature(type);
        for (int i = 0; i < 10; i++) {
            final int k = i;
            Scheduler.in(k * 2, () -> {
                Fx.movingRing(level, sig, player.position(), 1 + k * 0.6, 28, 0.2 + k * 0.15, 0.08);
                Fx.ring(level, ParticleTypes.SOUL_FIRE_FLAME, player.position(), 0.8 + k * 0.4, 16, k * 0.25);
            });
        }
        Fx.burst(level, ParticleTypes.EXPLOSION, c.add(0, 1, 0), 1, 0, 0);
    }

    // --------------------------------------------------------------------- use
    public static void use(ServerPlayer player, int idx) {
        if (idx < 0 || idx > 1) return;
        FruitType t = PowerData.get(player);
        if (t == null) {
            player.displayClientMessage(Component.translatable("msg.abyssfruits.no_power"), true);
            return;
        }
        if (player.isInWater()) { // the abyss hates water
            player.displayClientMessage(Component.translatable("msg.abyssfruits.water"), true);
            return;
        }
        ServerLevel level = (ServerLevel) player.level();
        long now = level.getGameTime();
        long ready = PowerData.readyAt(player, idx);
        if (now < ready) {
            player.displayClientMessage(Component.translatable("msg.abyssfruits.cooldown", (ready - now) / 20 + 1), true);
            return;
        }
        boolean ok = switch (t) {
            case SHADOW -> idx == 0 ? shadowStep(level, player) : summonWraiths(level, player);
            case BLOOD -> idx == 0 ? bloodDrain(level, player) : crimsonRage(level, player);
            case FLAME -> idx == 0 ? blackFlameBolt(level, player) : infernoRing(level, player);
            case GRAVITY -> idx == 0 ? gravityPull(level, player) : shockwave(level, player);
        };
        if (ok) {
            PowerData.setReadyAt(player, idx, now + t.cooldowns[idx]);
            player.displayClientMessage(Component.translatable("ability.abyssfruits." + t.id + "." + (idx + 1)), true);
        }
    }

    private static List<LivingEntity> around(ServerLevel level, ServerPlayer p, double r) {
        return level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r),
                e -> e != p && e.isAlive() && !(e instanceof ShadowWraith w && p.getUUID().equals(w.getOwnerId())));
    }

    // ------------------------------------------------------------------ SHADOW
    private static boolean shadowStep(ServerLevel level, ServerPlayer p) {
        Vec3 eye = p.getEyePosition();
        Vec3 dir = p.getLookAngle();
        Vec3 end = eye.add(dir.scale(14));
        BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 dest = hit.getType() == HitResult.Type.MISS ? end : hit.getLocation().subtract(dir.scale(0.9));
        Vec3 feet = dest.subtract(0, p.getEyeHeight(), 0);
        Vec3 from = p.position();
        Fx.line(level, AbyssFruits.SHADOW_WISP, from.add(0, 1, 0), feet.add(0, 1, 0), 0.4);
        Fx.line(level, Fx.darkDust(), from.add(0, 1, 0), feet.add(0, 1, 0), 0.7);
        Fx.burst(level, ParticleTypes.LARGE_SMOKE, from.add(0, 1, 0), 30, 0.5, 0.05);
        Fx.sound(level, from, SoundEvents.ENDERMAN_TELEPORT, 1f, 0.5f);
        p.teleportTo(feet.x, feet.y, feet.z);
        p.resetFallDistance();
        Fx.burst(level, AbyssFruits.SHADOW_WISP, feet.add(0, 1, 0), 40, 0.6, 0.08);
        Fx.ring(level, ParticleTypes.SCULK_SOUL, feet, 1.2, 20, 0.1);
        Fx.sound(level, feet, SoundEvents.ENDERMAN_TELEPORT, 1f, 0.8f);
        p.addEffect(new MobEffectInstance(MobEffects.SPEED, 60, 1));
        return true;
    }

    private static boolean summonWraiths(ServerLevel level, ServerPlayer p) {
        List<ShadowWraith> mine = level.getEntitiesOfClass(ShadowWraith.class, p.getBoundingBox().inflate(80),
                w -> p.getUUID().equals(w.getOwnerId()));
        if (mine.size() >= 4) {
            p.displayClientMessage(Component.translatable("msg.abyssfruits.max_minions"), true);
            return false;
        }
        for (int i = 0; i < 2; i++) {
            ShadowWraith w = AbyssFruits.WRAITH.create(level, EntitySpawnReason.MOB_SUMMONED);
            if (w == null) continue;
            double a = level.getRandom().nextDouble() * Math.PI * 2;
            Vec3 pos = p.position().add(Math.cos(a) * 2.5, 0, Math.sin(a) * 2.5);
            w.setPos(pos.x, pos.y, pos.z);
            w.setOwner(p.getUUID(), 20 * 40);
            level.addFreshEntity(w);
            Fx.burst(level, AbyssFruits.SHADOW_WISP, pos.add(0, 1, 0), 40, 0.5, 0.1);
            Fx.ring(level, Fx.darkDust(), pos, 1.0, 20, 0.1);
        }
        Fx.sound(level, p.position(), SoundEvents.ENDERMAN_SCREAM, 0.9f, 0.5f);
        return true;
    }

    // ------------------------------------------------------------------- BLOOD
    private static boolean bloodDrain(ServerLevel level, ServerPlayer p) {
        List<LivingEntity> list = around(level, p, 6);
        float total = 0;
        Vec3 pc = p.position().add(0, 1, 0);
        for (LivingEntity e : list) {
            if (e.hurtServer(level, level.damageSources().indirectMagic(p, p), 5f)) total += 5f;
            Fx.line(level, Fx.blood(), e.position().add(0, 1, 0), pc, 0.35);
            Fx.burst(level, AbyssFruits.BLOOD_DROP, e.position().add(0, 1, 0), 12, 0.3, 0.1);
        }
        if (list.isEmpty()) {
            Fx.ring(level, Fx.blood(), p.position(), 3, 24, 0.5);
        }
        p.heal(total * 0.6f);
        Fx.burst(level, AbyssFruits.BLOOD_DROP, pc, 25, 0.5, 0.05);
        Fx.sound(level, p.position(), SoundEvents.WARDEN_HEARTBEAT, 1.5f, 0.6f);
        return true;
    }

    private static boolean crimsonRage(ServerLevel level, ServerPlayer p) {
        if (p.getHealth() <= 8f) {
            p.displayClientMessage(Component.translatable("msg.abyssfruits.too_weak"), true);
            return false;
        }
        p.hurtServer(level, level.damageSources().magic(), 6f);
        p.addEffect(new MobEffectInstance(MobEffects.STRENGTH, 20 * 10, 1));
        p.addEffect(new MobEffectInstance(MobEffects.SPEED, 20 * 10, 1));
        p.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 20 * 10, 0));
        Vec3 c = p.position();
        for (int i = 0; i < 6; i++) {
            final int k = i;
            Scheduler.in(k * 2, () -> {
                Fx.movingRing(level, Fx.blood(), p.position(), 0.6, 24, 0.2 + k * 0.3, 0.25);
                Fx.burst(level, AbyssFruits.BLOOD_DROP, p.position().add(0, 0.5 + k * 0.3, 0), 10, 0.5, 0.05);
            });
        }
        Fx.sound(level, c, SoundEvents.ENDER_DRAGON_GROWL, 0.6f, 1.6f);
        return true;
    }

    // ------------------------------------------------------------------- FLAME
    private static boolean blackFlameBolt(ServerLevel level, ServerPlayer p) {
        Vec3 eye = p.getEyePosition();
        Vec3 dir = p.getLookAngle();
        Vec3 end = eye.add(dir.scale(22));
        BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (hit.getType() != HitResult.Type.MISS) end = hit.getLocation();
        Vec3 start = eye.add(dir.scale(1.2)).subtract(0, 0.3, 0);
        Fx.line(level, AbyssFruits.BLACK_EMBER, start, end, 0.3);
        Fx.line(level, ParticleTypes.SOUL_FIRE_FLAME, start, end, 0.6);
        Fx.line(level, Fx.darkDust(), start, end, 0.5);
        final Vec3 a = eye, b = end;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(a, b).inflate(2),
                x -> x != p && x.isAlive() && !(x instanceof ShadowWraith w && p.getUUID().equals(w.getOwnerId())))) {
            if (Fx.distToSegment(e.getBoundingBox().getCenter(), a, b) < 1.8) {
                e.igniteForSeconds(8);
                e.hurtServer(level, level.damageSources().indirectMagic(p, p), 7f);
                Fx.burst(level, AbyssFruits.BLACK_EMBER, e.position().add(0, 1, 0), 25, 0.4, 0.1);
            }
        }
        Fx.burst(level, ParticleTypes.EXPLOSION, b, 1, 0, 0);
        Fx.burst(level, AbyssFruits.BLACK_EMBER, b, 50, 0.7, 0.2);
        Fx.sound(level, eye, SoundEvents.BLAZE_SHOOT, 1.2f, 0.5f);
        return true;
    }

    private static boolean infernoRing(ServerLevel level, ServerPlayer p) {
        Vec3 c = p.position();
        for (LivingEntity e : around(level, p, 6)) {
            e.igniteForSeconds(6);
            Vec3 push = e.position().subtract(c).multiply(1, 0, 1).normalize().scale(1.3);
            e.setDeltaMovement(push.x, 0.5, push.z);
            e.hurtMarked = true;
            e.hurtServer(level, level.damageSources().indirectMagic(p, p), 5f);
        }
        p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 20 * 10, 0));
        for (int r = 1; r <= 6; r++) {
            final int rr = r;
            Scheduler.in(rr * 2, () -> {
                Fx.ring(level, AbyssFruits.BLACK_EMBER, c, rr, rr * 8, 0.2);
                Fx.ring(level, ParticleTypes.SOUL_FIRE_FLAME, c, rr, rr * 6, 0.1);
                Fx.ring(level, Fx.darkDust(), c, rr - 0.3, rr * 5, 0.5);
            });
        }
        Fx.sound(level, c, SoundEvents.FIRECHARGE_USE, 1.5f, 0.4f);
        Fx.sound(level, c, SoundEvents.BLAZE_SHOOT, 1f, 0.4f);
        return true;
    }

    // ----------------------------------------------------------------- GRAVITY
    private static boolean gravityPull(ServerLevel level, ServerPlayer p) {
        Vec3 c = p.position().add(0, 1, 0);
        for (LivingEntity e : around(level, p, 14)) {
            Vec3 v = c.subtract(e.position()).normalize().scale(1.4);
            e.setDeltaMovement(v.x, v.y * 0.8 + 0.35, v.z);
            e.hurtMarked = true;
            Fx.burst(level, AbyssFruits.GRAVITY_ORB, e.position().add(0, 1, 0), 10, 0.3, 0.05);
        }
        for (int i = 0; i < 6; i++) {
            final int k = i;
            Scheduler.in(k * 2, () -> {
                Fx.movingRing(level, AbyssFruits.GRAVITY_ORB, p.position(), 11 - k, 30, 1.0, -0.35);
                Fx.movingRing(level, Fx.gravityDust(), p.position(), 11 - k, 20, 0.4, -0.3);
            });
        }
        Fx.sound(level, c, SoundEvents.WARDEN_SONIC_BOOM, 0.8f, 0.5f);
        return true;
    }

    private static boolean shockwave(ServerLevel level, ServerPlayer p) {
        Vec3 c = p.position();
        for (LivingEntity e : around(level, p, 9)) {
            Vec3 out = e.position().subtract(c).multiply(1, 0, 1).normalize().scale(2.2);
            e.setDeltaMovement(out.x, 0.7, out.z);
            e.hurtMarked = true;
            e.hurtServer(level, level.damageSources().indirectMagic(p, p), 6f);
        }
        p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 20 * 6, 0));
        for (int r = 1; r <= 9; r++) {
            final int rr = r;
            Scheduler.in(rr, () -> {
                Fx.ring(level, AbyssFruits.GRAVITY_ORB, c, rr, rr * 7, 0.15);
                Fx.ring(level, Fx.gravityDust(), c, rr, rr * 5, 0.1);
                if (rr % 3 == 0) Fx.ring(level, ParticleTypes.ELECTRIC_SPARK, c, rr, rr * 4, 0.3);
            });
        }
        Fx.burst(level, ParticleTypes.EXPLOSION, c.add(0, 0.5, 0), 1, 0, 0);
        Fx.sound(level, c, SoundEvents.WARDEN_SONIC_BOOM, 1.4f, 0.8f);
        return true;
    }

    // ------------------------------------------------------------- passive aura
    public static void aura(ServerLevel level, ServerPlayer p, FruitType t) {
        long g = level.getGameTime();
        Vec3 pos = p.position();
        double a = g * 0.25;
        switch (t) {
            case SHADOW -> {
                level.sendParticles(AbyssFruits.SHADOW_WISP, pos.x + Math.cos(a) * 0.8, pos.y + 0.2 + (g % 20) * 0.08, pos.z + Math.sin(a) * 0.8, 1, 0.1, 0.1, 0.1, 0.01);
                if (g % 16 == 0) level.sendParticles(ParticleTypes.SQUID_INK, pos.x, pos.y + 1, pos.z, 2, 0.4, 0.6, 0.4, 0.01);
            }
            case BLOOD -> {
                level.sendParticles(Fx.blood(), pos.x + Math.cos(a) * 0.5, pos.y + 1.5, pos.z + Math.sin(a) * 0.5, 1, 0.1, 0, 0.1, 0);
                if (g % 12 == 0) level.sendParticles(AbyssFruits.BLOOD_DROP, pos.x, pos.y + 1.2, pos.z, 2, 0.4, 0.5, 0.4, 0.02);
            }
            case FLAME -> {
                level.sendParticles(AbyssFruits.BLACK_EMBER, pos.x + Math.cos(a) * 0.9, pos.y + 0.1 + Math.abs(Math.sin(a * 0.5)) * 1.6, pos.z + Math.sin(a) * 0.9, 1, 0.05, 0.05, 0.05, 0.01);
            }
            case GRAVITY -> {
                for (int i = 0; i < 3; i++) {
                    double b = a + i * Math.PI * 2 / 3;
                    level.sendParticles(AbyssFruits.GRAVITY_ORB, pos.x + Math.cos(b) * 1.1, pos.y + 1.0 + Math.sin(b * 1.0) * 0.5, pos.z + Math.sin(b) * 1.1, 1, 0, 0, 0, 0);
                }
            }
        }
    }
}
