#!/usr/bin/env python3
"""Generates 3D item models (JSON cuboids), textures, particle textures, lang and recipes."""
import json, math, os, random
from PIL import Image, ImageFilter

random.seed(1337)
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources")
A = os.path.join(ROOT, "assets", "abyssfruits")
D = os.path.join(ROOT, "data", "abyssfruits")
for p in ["items", "models/item", "textures/item", "textures/entity", "textures/particle", "particles", "lang"]:
    os.makedirs(os.path.join(A, p), exist_ok=True)
os.makedirs(os.path.join(D, "recipe"), exist_ok=True)

def mix(a, b, t):
    t = max(0, min(1, t))
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

# ----------------------------------------------------------------- textures
PAL = {
    "shadow":  dict(c=[(14, 8, 24), (46, 20, 72), (112, 60, 170)], vein=(8, 2, 14),  glow=(180, 90, 255)),
    "blood":   dict(c=[(55, 0, 6), (128, 6, 16), (205, 34, 44)],   vein=(30, 0, 2),  glow=(255, 50, 50)),
    "flame":   dict(c=[(14, 10, 12), (62, 26, 16), (255, 112, 22)], vein=(5, 3, 4),  glow=(255, 150, 40)),
    "gravity": dict(c=[(10, 12, 36), (30, 42, 112), (112, 142, 255)], vein=(4, 5, 18), glow=(150, 205, 255)),
}

def walk(px, size, col, steps, thick=1):
    x, y = random.randrange(size), random.randrange(size)
    dx, dy = random.choice([-1, 0, 1]), random.choice([-1, 1])
    for _ in range(steps):
        for t in range(thick):
            px[(x + t) % size, y % size] = col
        if random.random() < 0.3:
            dx = random.choice([-1, 0, 1])
        x += dx; y += dy

def fruit_texture(name, pal, size=64):
    small = Image.new("L", (8, 8))
    sp = small.load()
    for x in range(8):
        for y in range(8):
            sp[x, y] = random.randint(0, 255)
    big = small.resize((size, size), Image.BICUBIC).filter(ImageFilter.GaussianBlur(1.2))
    bp = big.load()
    img = Image.new("RGB", (size, size))
    px = img.load()
    c0, c1, c2 = pal["c"]
    for x in range(size):
        for y in range(size):
            n = bp[x, y] / 255 * 0.75 + random.random() * 0.25
            n = n - (y / size) * 0.1
            px[x, y] = mix(c0, c1, n * 1.6) if n < 0.5 else mix(c1, c2, (n - 0.5) * 2)
    for _ in range(14):
        walk(px, size, pal["vein"], random.randint(25, 60), 2)
    for _ in range(7):
        walk(px, size, pal["glow"], random.randint(10, 30), 1)
    img.save(os.path.join(A, "textures/item", f"{name}_fruit.png"))
    g = Image.new("RGB", (16, 16))
    gp = g.load()
    for x in range(16):
        for y in range(16):
            gp[x, y] = mix(pal["glow"], (255, 255, 255), random.random() * 0.45)
    g.save(os.path.join(A, "textures/item", f"{name}_fruit_glow.png"))

for n, p in PAL.items():
    fruit_texture(n, p)

def blob(path, core, rim, kind="round", size=16):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    px = img.load()
    c = (size - 1) / 2
    for x in range(size):
        for y in range(size):
            if kind == "drop":
                dx, dy = (x - c) / (size * 0.28), (y - c - 1.5) / (size * 0.4)
                d = math.sqrt(dx * dx + dy * dy)
                if y < c - 2:
                    d += (c - 2 - y) * 0.25
            else:
                d = math.hypot(x - c, y - c) / (size * 0.5)
            if d < 1:
                t = d
                col = mix(core, rim, t ** 1.5)
                a = int(255 * (1 - t ** 3))
                px[x, y] = (*col, max(40, a))
    img.save(path)

pt = os.path.join(A, "textures/particle")
blob(os.path.join(pt, "shadow_wisp.png"), (10, 0, 20), (150, 70, 230))
blob(os.path.join(pt, "blood_drop.png"), (150, 0, 10), (255, 40, 40), "drop")
blob(os.path.join(pt, "black_ember.png"), (6, 0, 10), (255, 120, 20))
blob(os.path.join(pt, "gravity_orb.png"), (235, 245, 255), (60, 110, 255))
for n in ["shadow_wisp", "blood_drop", "black_ember", "gravity_orb"]:
    json.dump({"textures": [f"abyssfruits:{n}"]}, open(os.path.join(A, "particles", f"{n}.json"), "w"))

# wraith entity texture (64x64) matching WraithModel UV layout
w = Image.new("RGB", (64, 64))
wp = w.load()
for x in range(64):
    for y in range(64):
        n = random.random()
        wp[x, y] = mix((8, 4, 14), (40, 18, 62), n * 0.9)
for _ in range(30):
    walk(wp, 64, (90, 40, 140), random.randint(6, 16), 1)
# head front face = u 8..16, v 8..16
for (ex, ey) in [(9, 11), (13, 11)]:
    for dx in range(2):
        wp[ex + dx, ey] = (255, 30, 30)
        wp[ex + dx, ey - 1] = (255, 140, 60)
for x in range(10, 15):
    wp[x, 14] = (0, 0, 0)
for x in range(10, 15, 2):
    wp[x, 13] = (210, 210, 220)
w.save(os.path.join(A, "textures/entity/shadow_wraith.png"))

egg = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
ep = egg.load()
for x in range(16):
    for y in range(16):
        dx, dy = (x - 7.5) / 5, (y - 8.5) / 6.5
        if dx * dx + dy * dy < 1:
            ep[x, y] = (30, 14, 48, 255) if (x * 3 + y * 5) % 7 else (160, 60, 220, 255)
egg.save(os.path.join(A, "textures/item/shadow_wraith_spawn_egg.png"))

# ----------------------------------------------------------------- 3D models
def box(f, t, tex="#0", rot=None, emit=0):
    faces = {}
    for d in ["north", "east", "south", "west", "up", "down"]:
        face = {"texture": tex}
        if emit:
            face["light_emission"] = emit
        faces[d] = face
    e = {"from": [round(v, 3) for v in f], "to": [round(v, 3) for v in t], "faces": faces}
    if rot:
        e["rotation"] = rot
    return e

def rot(axis, angle, origin=(8, 8, 8)):
    return {"origin": list(origin), "axis": axis, "angle": angle}

def ellipsoid(cx, cy, cz, rx, ry, rz, tex="#0"):
    els = []
    n = max(3, int(ry * 2))
    h = 2 * ry / n
    for i in range(n):
        y0 = cy - ry + i * h
        y1 = y0 + h
        k = 1 - (((y0 + y1) / 2 - cy) / ry) ** 2
        if k <= 0:
            continue
        s = math.sqrt(k)
        wx, wz = rx * s, rz * s
        els.append(box([cx - wx, y0, cz - wz * 0.8], [cx + wx, y1, cz + wz * 0.8], tex))
        els.append(box([cx - wx * 0.8, y0 + 0.02, cz - wz], [cx + wx * 0.8, y1 - 0.02, cz + wz], tex))
    return els

def shadow():
    e = ellipsoid(8, 7.5, 8, 6.5, 7, 6.2)
    e.append(box([7.2, 14, 7.2], [8.8, 17, 8.8]))
    e.append(box([7.2, 16.4, 7.2], [10.2, 17.8, 8.8]))
    e.append(box([8.5, 13.4, 7.6], [13.5, 14.1, 8.4], rot=rot("z", -22.5, (8.5, 13.7, 8))))
    e.append(box([2.5, 13.4, 7.6], [7.5, 14.1, 8.4], rot=rot("z", 22.5, (7.5, 13.7, 8))))
    e.append(box([4.5, 8, 1.55], [11.5, 9.2, 1.9], "#1", emit=15))       # glowing eye slit
    e.append(box([5.5, 9.8, 1.6], [6.6, 10.6, 1.9], "#1", emit=15))
    e.append(box([9.4, 9.8, 1.6], [10.5, 10.6, 1.9], "#1", emit=15))
    for i in range(7):                                                    # hanging shadow tendrils
        a = i * math.tau / 7
        x, z = 8 + math.cos(a) * 3.4, 8 + math.sin(a) * 3.4
        e.append(box([x, -3.5 - (i % 3), z], [x + 0.7, 1.2, z + 0.7]))
    return e

def blood():
    e = ellipsoid(5.3, 8.5, 8, 4.9, 6.5, 5.3) + ellipsoid(10.7, 8.5, 8, 4.9, 6.5, 5.3)
    e += ellipsoid(8, 3, 8, 3.2, 3.2, 3.2)
    e.append(box([5, 14, 6.5], [6.8, 17.5, 8.3], rot=rot("z", -22.5, (6, 14, 7.5))))
    e.append(box([9.2, 14, 6.5], [11, 16.5, 8.3], rot=rot("z", 22.5, (10, 14, 7.5))))
    for x, y0, h in [(3.5, 5, 5), (6, 8, 4), (8.5, 3, 6), (10.5, 7, 5), (12.5, 5, 4)]:   # raised veins
        e.append(box([x, y0, 1.6], [x + 0.55, y0 + h, 2.05], "#0"))
    e.append(box([7.4, 4, 1.5], [8.6, 12, 1.8], "#1", emit=10))          # pulsing core slit
    for x, z, l in [(4, 6, 3), (7, 9, 4), (10, 7, 2.5), (12, 9, 3.5)]:  # blood drips
        e.append(box([x, -l, z], [x + 0.7, 1.5, z + 0.7], "#1", emit=6))
        e.append(box([x - 0.25, -l - 1.3, z - 0.25], [x + 0.95, -l, z + 0.95], "#1", emit=8))
    return e

def flame():
    e = ellipsoid(8, 5, 8, 6.6, 5, 6.6) + ellipsoid(8, 10.4, 8, 4.2, 3.6, 4.2)
    for i, (x, z) in enumerate([(3.2, 8), (12.8, 8), (8, 3.2), (8, 12.8)]):   # horn spikes
        e.append(box([x - 0.7, 9.5, z - 0.7], [x + 0.7, 13.5, z + 0.7],
                     rot=rot("z" if i < 2 else "x", 22.5 if i % 2 else -22.5, (x, 9.5, z))))
    for i in range(7):                                                         # black flame crown
        s = 3.4 - 0.46 * i
        e.append(box([8 - s / 2, 13.8 + i * 0.95, 8 - s / 2], [8 + s / 2, 14.75 + i * 0.95, 8 + s / 2],
                     "#1" if i % 2 else "#0", rot=rot("y", 22.5 * (i % 3), (8, 0, 8)), emit=15 if i % 2 else 0))
    for x, y, h in [(4, 2, 4), (7, 4, 5), (10.5, 3, 4), (12, 6, 3)]:           # glowing cracks
        e.append(box([x, y, 1.45], [x + 0.6, y + h, 1.8], "#1", emit=15))
    return e

def gravity():
    e = ellipsoid(8, 8, 8, 6, 6, 6)
    R, half, th = 8.7, 3.55, 0.9
    e.append(box([8 - half, 7.55, 8 + R - th], [8 + half, 8.45, 8 + R + th], "#1", emit=12))
    e.append(box([8 - half, 7.55, 8 - R - th], [8 + half, 8.45, 8 - R + th], "#1", emit=12))
    e.append(box([8 + R - th, 7.55, 8 - half], [8 + R + th, 8.45, 8 + half], "#1", emit=12))
    e.append(box([8 - R - th, 7.55, 8 - half], [8 - R + th, 8.45, 8 + half], "#1", emit=12))
    for ang in (-45, 45):
        for z0 in (8 + R, 8 - R):
            zz = z0 - th if z0 > 8 else z0 - th
            e.append(box([8 - half, 7.55, z0 - th], [8 + half, 8.45, z0 + th], "#1", rot=rot("y", ang), emit=12))
    for x, y, z in [(1, 13, 3), (15, 3, 13), (14, 14, 2), (2, 2, 14)]:         # floating shards
        e.append(box([x, y, z], [x + 1.3, y + 1.8, z + 1.3], "#1", rot=rot("z", 22.5, (x, y, z)), emit=15))
    e.append(box([7.4, 3, 1.7], [8.6, 13, 2.1], "#1", emit=15))
    return e

BUILD = {"shadow": shadow, "blood": blood, "flame": flame, "gravity": gravity}
DISPLAY = {
    "gui": {"rotation": [25, -35, 0], "translation": [0, 0, 0], "scale": [0.78, 0.78, 0.78]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 3, 0], "scale": [0.45, 0.45, 0.45]},
    "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [0.7, 0.7, 0.7]},
    "thirdperson_righthand": {"rotation": [0, 0, 0], "translation": [0, 3, 1], "scale": [0.55, 0.55, 0.55]},
    "thirdperson_lefthand": {"rotation": [0, 0, 0], "translation": [0, 3, 1], "scale": [0.55, 0.55, 0.55]},
    "firstperson_righthand": {"rotation": [0, -30, 0], "translation": [1, 1, 0], "scale": [0.6, 0.6, 0.6]},
    "firstperson_lefthand": {"rotation": [0, 30, 0], "translation": [1, 1, 0], "scale": [0.6, 0.6, 0.6]},
    "head": {"rotation": [0, 180, 0], "translation": [0, 13, 7], "scale": [1, 1, 1]},
}

for name, fn in BUILD.items():
    els = fn()
    model = {
        "textures": {
            "0": f"abyssfruits:item/{name}_fruit",
            "1": f"abyssfruits:item/{name}_fruit_glow",
            "particle": f"abyssfruits:item/{name}_fruit",
        },
        "gui_light": "side",
        "elements": els,
        "display": DISPLAY,
    }
    json.dump(model, open(os.path.join(A, "models/item", f"{name}_fruit.json"), "w"))
    json.dump({"model": {"type": "minecraft:model", "model": f"abyssfruits:item/{name}_fruit"}},
              open(os.path.join(A, "items", f"{name}_fruit.json"), "w"))
    print(name, "elements:", len(els))

json.dump({"parent": "minecraft:item/generated", "textures": {"layer0": "abyssfruits:item/shadow_wraith_spawn_egg"}},
          open(os.path.join(A, "models/item/shadow_wraith_spawn_egg.json"), "w"))
json.dump({"model": {"type": "minecraft:model", "model": "abyssfruits:item/shadow_wraith_spawn_egg"}},
          open(os.path.join(A, "items/shadow_wraith_spawn_egg.json"), "w"))

# ----------------------------------------------------------------- lang
EN = {
    "item.abyssfruits.shadow_fruit": "Umbral Abyss Fruit",
    "item.abyssfruits.blood_fruit": "Crimson Heart Fruit",
    "item.abyssfruits.flame_fruit": "Black Flame Fruit",
    "item.abyssfruits.gravity_fruit": "Void Gravity Fruit",
    "item.abyssfruits.shadow_wraith_spawn_egg": "Shadow Wraith Spawn Egg",
    "entity.abyssfruits.shadow_wraith": "Shadow Wraith",
    "key.category.abyssfruits.main": "Abyss Fruits",
    "key.abyssfruits.ability1": "Fruit Ability 1",
    "key.abyssfruits.ability2": "Fruit Ability 2",
    "ability.abyssfruits.shadow.1": "Shadow Step", "ability.abyssfruits.shadow.2": "Summon Wraiths",
    "ability.abyssfruits.blood.1": "Blood Drain", "ability.abyssfruits.blood.2": "Crimson Rage",
    "ability.abyssfruits.flame.1": "Black Flame Bolt", "ability.abyssfruits.flame.2": "Inferno Ring",
    "ability.abyssfruits.gravity.1": "Gravity Pull", "ability.abyssfruits.gravity.2": "Shockwave",
    "msg.abyssfruits.no_power": "You have no fruit power.",
    "msg.abyssfruits.water": "The abyss hates water - your power won't answer.",
    "msg.abyssfruits.cooldown": "Cooling down: %s s",
    "msg.abyssfruits.too_weak": "You are too weak to pay the blood price.",
    "msg.abyssfruits.max_minions": "Too many wraiths already.",
    "msg.abyssfruits.rejected": "The abyss rejects a second fruit...",
    "msg.abyssfruits.awakened.shadow": "The shadows bow to you.",
    "msg.abyssfruits.awakened.blood": "Your blood roars.",
    "msg.abyssfruits.awakened.flame": "Black fire wakes inside you.",
    "msg.abyssfruits.awakened.gravity": "The world grows heavy around you.",
}
AR = dict(EN)
AR.update({
    "item.abyssfruits.shadow_fruit": "فاكهة الظلال الهاوية",
    "item.abyssfruits.blood_fruit": "فاكهة القلب القرمزي",
    "item.abyssfruits.flame_fruit": "فاكهة اللهب الأسود",
    "item.abyssfruits.gravity_fruit": "فاكهة جاذبية الفراغ",
    "item.abyssfruits.shadow_wraith_spawn_egg": "بيضة استدعاء شبح الظل",
    "entity.abyssfruits.shadow_wraith": "شبح الظل",
    "key.category.abyssfruits.main": "فواكه الهاوية",
    "key.abyssfruits.ability1": "قدرة الفاكهة 1", "key.abyssfruits.ability2": "قدرة الفاكهة 2",
    "ability.abyssfruits.shadow.1": "خطوة الظل", "ability.abyssfruits.shadow.2": "استدعاء الأشباح",
    "ability.abyssfruits.blood.1": "امتصاص الدم", "ability.abyssfruits.blood.2": "الغضب القرمزي",
    "ability.abyssfruits.flame.1": "سهم اللهب الأسود", "ability.abyssfruits.flame.2": "حلقة الجحيم",
    "ability.abyssfruits.gravity.1": "سحب الجاذبية", "ability.abyssfruits.gravity.2": "الموجة الصادمة",
    "msg.abyssfruits.no_power": "ما عندك قدرة فاكهة.",
    "msg.abyssfruits.water": "الهاوية تكره الماء، القدرة ما تستجيب.",
    "msg.abyssfruits.cooldown": "فترة انتظار: %s ثانية",
    "msg.abyssfruits.too_weak": "انت ضعيف جداً، ما تقدر تدفع ثمن الدم.",
    "msg.abyssfruits.max_minions": "عندك أشباح كثيرة.",
    "msg.abyssfruits.rejected": "الهاوية ترفض فاكهة ثانية...",
    "msg.abyssfruits.awakened.shadow": "الظلال تنحني لك.",
    "msg.abyssfruits.awakened.blood": "دمك يزمجر.",
    "msg.abyssfruits.awakened.flame": "نار سوداء تستيقظ بداخلك.",
    "msg.abyssfruits.awakened.gravity": "العالم يثقل من حولك.",
})
for code, d in (("en_us", EN), ("ar_sa", AR)):
    json.dump(d, open(os.path.join(A, "lang", f"{code}.json"), "w"), ensure_ascii=False, indent=2)

# ----------------------------------------------------------------- recipes
RECIPES = {
    "shadow_fruit": (["SDS", "DED", "SDS"], {"S": "minecraft:sculk", "D": "minecraft:black_dye", "E": "minecraft:ender_eye"}),
    "blood_fruit": (["RFR", "FGF", "RFR"], {"R": "minecraft:redstone_block", "F": "minecraft:rotten_flesh", "G": "minecraft:golden_apple"}),
    "flame_fruit": (["BNB", "NCN", "BNB"], {"B": "minecraft:blaze_rod", "N": "minecraft:netherite_scrap", "C": "minecraft:fire_charge"}),
    "gravity_fruit": (["OAO", "ASA", "OAO"], {"O": "minecraft:obsidian", "A": "minecraft:amethyst_shard", "S": "minecraft:nether_star"}),
}
for n, (pat, key) in RECIPES.items():
    json.dump({"type": "minecraft:crafting_shaped", "category": "misc", "pattern": pat, "key": key,
               "result": {"id": f"abyssfruits:{n}", "count": 1}},
              open(os.path.join(D, "recipe", f"{n}.json"), "w"), indent=2)
print("assets generated")
